//  Created by Gavin MacLean on 2017-09-19.
//  Copyright 2017 Bohemian Coding. All rights reserved.

var pluginMinVersion = 47

function correctFillsInRawLayer(layer){
  var fills = layer.style().fills()
  var loop = fills.objectEnumerator()
  while (fill = loop.nextObject()) {
    if (fill.image() != null) {
      fill.image().correctInvalidGamma()
      /*
        self.image = [NSImage imageWithDataFixingInvalidGamma:self.data];
        self.data = [self.image dataForArchiving];
        self.sha1 = self.data.sha1;
      */
      /*
        // imageWithDataFixingInvalidGamma
        if (BCRunningSierra() || BCRunningElCapitan()) {
          // Only works on 10.13 or above
          return [[NSImage alloc] initWithData:data];
        }
        CGImageSourceRef source = CGImageSourceCreateWithData( (CFDataRef)data, NULL );
        NSDictionary *properties = (NSDictionary*)CFBridgingRelease(CGImageSourceCopyPropertiesAtIndex( source, 0, NULL ));
        CFRelease(source);
        NSDictionary *pngProperties = properties[(NSString*)kCGImagePropertyPNGDictionary];
        if (pngProperties) {
          NSNumber *gamma = pngProperties[(NSString*)kCGImagePropertyPNGGamma];
          if (gamma && gamma.floatValue > 1.0) {
            data = [self pngDataByInvertingGammaInData:data];
          }
        }
        return [[NSImage alloc] initWithData:data];
      */
    }
  }
}

function convertImagesUnder( layer ) {
  layer.iterate( function(subLayer) {


    // Bitmap Layers
    if (subLayer.isImage) {
      log(subLayer.name + " is a bitmap layer. Fixing!")
      subLayer.sketchObject.correctInvalidGamma()
    } else if (subLayer.isGroup) {
      convertImagesUnder(subLayer)
    }


    // Symbols need a special treatment. Since they're not (yet) wrapped by SketchAPI, we'll access the raw layers, like animals
    if (subLayer.name == undefined ) {
      var rawLayer = subLayer._object
      if(rawLayer.className() == "MSSymbolMaster") {
        var loop = rawLayer.children().objectEnumerator()
        while (item = loop.nextObject()) {
          // log(item.className())
          if (item.className() == "MSBitmapLayer") {
            item.correctInvalidGamma()
          }
          if (item.className() == "MSShapeGroup") {
            correctFillsInRawLayer(item)
          }
        }
      }
      // While we're here, let's fix symbol overrides
      if(rawLayer.className() == "MSSymbolInstance") {
        log("Symbol instance:")
        var overrides = rawLayer.overrides()
        for (var key in overrides){
          if(overrides.objectForKey(key).className() == "MSImageData") {
            log("MSImageData: " + overrides.objectForKey(key))
            overrides.objectForKey(key).correctInvalidGamma()
          }
        }
        // Set overrides again
        rawLayer.overrides = overrides
      }
    }


    // Bitmap Fills
    if (subLayer.isShape) {
      correctFillsInRawLayer(subLayer._object)
    }

  })
}

function convertImagesInDocument( doc ) {
  var pages = doc.pages
  for (var i=0; i < pages.length; i++ ) {
   convertImagesUnder( pages[i] )
  }
}

function checkVersion(sketch) {
  var bundle = [NSBundle bundleForClass:sketch];
  var info = bundle.infoDictionary()
  var version = parseInt(info.valueForKey("CFBundleShortVersionString"))
  return version >= pluginMinVersion
}

function runningOnHighSierraOrLater() {
  // Bit brutal, but Cocoascript doesn't understand the NSOperatingSystemVersion struct - or at least I can't get it to at any rate ;-)
  var version = NSProcessInfo.processInfo().operatingSystemVersionString()
  // Strip the start - "Version 10."
  version = version.replace(/[^0-9]+[0-9]+[^0-9]*/, '' )
  return parseFloat(version) >= 13.0
}

function onCorrectInvalidGamma(context) {
  var sketch = context.api()
  if (checkVersion(sketch)) {
    if (runningOnHighSierraOrLater()) {
      var doc = sketch.selectedDocument
      var historyMaker = doc.sketchObject.historyMaker()
      historyMaker.registerHistoryMomentTitle("Gamma Correction")
      convertImagesInDocument( doc )
    } else {
      sketch.alert( "Error", "This plugin can only be run on macOS 10.13 or above." );
    }
  } else {
    sketch.alert( "This plugin requires Sketch version " + pluginMinVersion + " or above.", "Error" );
  }
}

// If you have questions, comments or any feedback, ping us at <developer@sketchapp.com>!
